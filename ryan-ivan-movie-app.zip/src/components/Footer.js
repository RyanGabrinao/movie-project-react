import React from "react";

function Footer() {
  return (
    <>
      <footer>
        <p>&copy; WHAT'S POPPIN all rights reserved.</p>
        <p>Created by Ryan Gabrinao and Ivan Kam.</p>
      </footer>
    </>
  );
}

export default Footer;
