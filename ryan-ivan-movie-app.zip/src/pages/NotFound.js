import React from "react";

function NotFound() {
  return (
    <div>
      <h2>Not Found</h2>
    </div>
  );
}

export default NotFound;
